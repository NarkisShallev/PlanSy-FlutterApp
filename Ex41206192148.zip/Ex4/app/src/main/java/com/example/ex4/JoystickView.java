package com.example.ex4;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import static android.view.MotionEvent.ACTION_UP;

public class JoystickView extends SurfaceView implements SurfaceHolder.Callback, View.OnTouchListener {

    public JoystickView(Context context) {
        super(context);
        getHolder().addCallback(this);
        setOnTouchListener(this);
    }

    public void surfaceCreated(SurfaceHolder holder){
        drawInXY(getWidth()/2, getHeight()/2);
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){

    }

    public void surfaceDestroyed(SurfaceHolder holder){

    }

    public void drawInXY(float x, float y){
        Canvas canvas = this.getHolder().lockCanvas();
        Paint paint = new Paint();

        // clear the canvas before painting
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

        // draw background
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#D75365E6"));
        canvas.drawPaint(paint);

        // draw oval behind the joystick
        paint.setColor(Color.parseColor("#cdc9c9"));
        RectF oval = new RectF(100, 400, getWidth()-100, getHeight()-400);
        canvas.drawOval(oval, paint);

        // draw joystick
        paint.setColor(Color.parseColor("#00cd66"));
        canvas.drawCircle(x, y, 175, paint);

        getHolder().unlockCanvasAndPost(canvas);
    }

    public boolean onTouch(View v, MotionEvent e){
        if(e.getAction() != MotionEvent.ACTION_UP){
            drawInXY(e.getX(), e.getY());
        } else {
            drawInXY(getWidth() / 2, getHeight() / 2);
        }
        return true;
    }
}
